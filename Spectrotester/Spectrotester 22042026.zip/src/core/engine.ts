/**
 * Spectrotester core orchestrator.
 * run({ smiles?, formula?, context, observedSpectra, scenario }) => { predicted, verification_report, coverage_report }
 */

import { parseSmiles } from './graph/parseSmiles.js';
import { computeGraphFeatures, type MoleculeGraph, type GraphFeatures } from './graph/features.js';
import { loadRules } from './library/loadRules.js';
import { evaluateRules } from './verify/evaluateRules.js';
import { aggregateScoring } from './verify/scoring.js';
import {
  buildReport,
  featureSnapshotFromGraph,
  buildArtifactHashes,
} from './verify/report.js';
import { createTimers } from './util/timers.js';
import type { LibraryLoader } from './library/loadLibrary.js';

export interface RunInput {
  smiles?: string;
  formula?: string;
  context?: Record<string, unknown>;
  observedSpectra?: Record<string, unknown>;
  scenario?: string;
  /** Precomputed graph (e.g. from SpectroMind parse_and_standardize) */
  precomputedGraph?: MoleculeGraph;
  /** API base URL for parse (if no precomputedGraph) */
  apiBase?: string;
  /** Load JSON from path (Node: fs; browser: fetch) */
  loadJson?: LibraryLoader;
  libraryPath?: string;
  engineId?: string;
}

export interface RunResult {
  success: boolean;
  parseError?: string;
  root_cause_code?: string;
  verification_report?: Record<string, unknown>;
  coverage_report?: Record<string, unknown>;
  predicted?: unknown;
  feature_snapshot?: Record<string, unknown>;
}

export async function run(input: RunInput): Promise<RunResult> {
  const timers = createTimers();
  timers.start('parse');

  const smiles = (input.smiles ?? input.precomputedGraph?.canonicalSmiles)?.trim();
  if (!smiles && !input.precomputedGraph) {
    return {
      success: false,
      parseError: 'SMILES or precomputedGraph required',
      root_cause_code: 'PARSER_FAIL:NO_INPUT',
    };
  }

  const parseResult = await parseSmiles(smiles ?? '', {
    apiBase: input.apiBase,
    precomputedGraph: input.precomputedGraph,
  });

  timers.stop('parse');

  if (!parseResult.success || !parseResult.moleculeGraph) {
    return {
      success: false,
      parseError: parseResult.message,
      root_cause_code: parseResult.rootCause ?? 'PARSER_FAIL',
      verification_report: {
        status: 'INCONCLUSIVE',
        overall: 'BELIRSIZ',
        summary: parseResult.message ?? 'Parse başarısız.',
        confidence_score: 0,
        root_cause_code: parseResult.rootCause,
        recommended_action: 'SMILES doğrulayın veya canonicalize edin.',
        engine_used: input.engineId ?? 'spectrotester',
        inputs_echo: { smiles: input.smiles },
        timings_ms: timers.timers,
        artifact_hashes: {},
        trace: {},
      },
    };
  }

  const graph = parseResult.moleculeGraph;
  const features = computeGraphFeatures(graph);

  if (features.dbe < 0) {
    return {
      success: false,
      root_cause_code: 'FORMULA_DBE_NEGATIVE_FATAL',
      verification_report: {
        status: 'FAIL',
        overall: 'FAIL',
        summary: 'DBE negatif; formül/çekirdek tutarsız.',
        confidence_score: 0,
        root_cause_code: 'FORMULA_DBE_NEGATIVE_FATAL',
        recommended_action: 'Formül ve SMILES tutarlılığını kontrol edin.',
        engine_used: input.engineId ?? 'spectrotester',
        inputs_echo: { smiles: graph.canonicalSmiles, formula: input.formula },
        timings_ms: timers.timers,
        artifact_hashes: buildArtifactHashes({
          inputSmiles: graph.canonicalSmiles,
          rulesetVersion: '1.1',
        }),
        trace: {},
        feature_snapshot: featureSnapshotFromGraph(features),
      },
    };
  }

  timers.start('verify');

  const { data: ruleset } = await loadRules({
    loadJson: input.loadJson,
    libraryPath: input.libraryPath,
  });

  const ruleResults = ruleset
    ? evaluateRules(ruleset.rules, {
        engineId: input.engineId ?? 'spectrotester',
        graphFeatures: features,
        canonicalSmiles: graph.canonicalSmiles,
        dbeValue: features.dbe,
        formulaRef: input.formula ?? graph.formula,
        atomCounts: graph.atomCounts,
        h1: (input.observedSpectra?.h1 as { peaks?: Array<{ ppm: number; integral?: number; mult?: string; j?: number[] }> } | undefined),
        c13Peaks: (input.observedSpectra?.c13Peaks as Array<{ ppm: number; integral?: number; mult?: string }> | undefined),
        c13Signals: (input.observedSpectra?.c13Signals as number | undefined),
        hsqcPeaks: (input.observedSpectra?.hsqcPeaks as Array<{ f1: number; f2: number; intensity?: number }> | undefined),
        cosyPeaks: (input.observedSpectra?.cosyPeaks as Array<{ f1: number; f2: number; intensity?: number }> | undefined),
        hmbcPeaks: (input.observedSpectra?.hmbcPeaks as Array<{ f1: number; f2: number; intensity?: number }> | undefined),
        noesyPeaks: (input.observedSpectra?.noesyPeaks as Array<{ f1: number; f2: number; intensity?: number }> | undefined),
        ftirPeaks: (input.observedSpectra?.ftirPeaks as Array<{ cm: number; intensity?: string }> | undefined),
        msPeaks: (input.observedSpectra?.msPeaks as Array<{ mz: number; intensity: number }> | undefined),
        solvent: (input.context?.solvent_name as string | undefined),
        fieldMHz: (input.context?.field_mhz as number | undefined),
        ionMode: (input.context?.ion_mode as 'positive' | 'negative' | 'EI' | undefined),
        snrClass: (input.context?.snr_class as 'normal' | 'lowSNR' | 'highRes' | undefined),
        thresholdProfile: (input.context?.tolerance_profile_id as string | undefined),
        observedSpectra: input.observedSpectra,
        meta: input.context,
      })
    : [];

  const scoring = aggregateScoring(ruleResults);
  timers.stop('verify');

  const status =
    scoring.overall === 'FAIL' ? 'FAIL' : scoring.overall === 'WARN' ? 'PARTIAL' : 'PASS';
  const overall =
    scoring.overall === 'FAIL' ? 'FAIL' : scoring.overall === 'WARN' ? 'WARN' : 'PASS';

  const verification_report = buildReport({
    status,
    overall: overall as 'PASS' | 'WARN' | 'FAIL' | 'BELIRSIZ',
    summary:
      scoring.overall === 'FAIL'
        ? `${scoring.vetoCount + scoring.failCount} kural ihlali.`
        : scoring.overall === 'WARN'
          ? `${scoring.warnCount} uyarı.`
          : 'Teyit kuralları geçti.',
    confidence_score: scoring.confidenceScore,
    ruleResults,
    scoring,
    inputs_echo: {
      smiles: graph.canonicalSmiles,
      formula: input.formula ?? graph.formula,
      scenario: input.scenario,
      provenance_type: input.context?.provenance_type,
    },
    timings_ms: timers.timers,
    artifact_hashes: buildArtifactHashes({
      inputSmiles: graph.canonicalSmiles,
      configSnapshot: { scenario: input.scenario },
      rulesetVersion: ruleset?.version ?? '1.1',
    }),
    trace: {
      parse_summary: 'graph_ok',
      peak_counts: {},
    },
    feature_snapshot: featureSnapshotFromGraph(features),
    engine_used: input.engineId ?? 'spectrotester',
  });

  return {
    success: true,
    verification_report,
    coverage_report: {},
    feature_snapshot: featureSnapshotFromGraph(features),
  };
}
