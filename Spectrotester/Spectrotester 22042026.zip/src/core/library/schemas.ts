/**
 * Schema validation for library and report. Uses minimal checks (no Ajv dependency)
 * so core stays lightweight; optional Ajv can be added later for full JSON Schema.
 */

export function validateRuleShape(rule: unknown): { ok: boolean; error?: string } {
  if (!rule || typeof rule !== 'object') return { ok: false, error: 'rule must be object' };
  const r = rule as Record<string, unknown>;
  if (typeof r.rule_id !== 'string' || r.rule_id.length < 5) return { ok: false, error: 'rule_id required (min 5)' };
  if (!['HARD', 'SOFT', 'INFO'].includes(r.hardness as string)) return { ok: false, error: 'hardness must be HARD|SOFT|INFO' };
  return { ok: true };
}

export function validateRuleset(data: unknown): { ok: boolean; error?: string } {
  if (!data || typeof data !== 'object') return { ok: false, error: 'ruleset must be object' };
  const d = data as Record<string, unknown>;
  const rules = d.rules;
  if (!Array.isArray(rules)) return { ok: false, error: 'ruleset.rules must be array' };
  for (let i = 0; i < rules.length; i++) {
    const v = validateRuleShape(rules[i]);
    if (!v.ok) return { ok: false, error: `rules[${i}]: ${v.error}` };
  }
  return { ok: true };
}

export function validateReportShape(report: unknown): { ok: boolean; error?: string } {
  if (!report || typeof report !== 'object') return { ok: false, error: 'report must be object' };
  const r = report as Record<string, unknown>;
  const status = r.status;
  if (!['PASS', 'FAIL', 'PARTIAL', 'INCONCLUSIVE'].includes(status as string)) return { ok: false, error: 'status must be PASS|FAIL|PARTIAL|INCONCLUSIVE' };
  if (typeof r.overall !== 'string') return { ok: false, error: 'overall required' };
  if (typeof r.summary !== 'string') return { ok: false, error: 'summary required' };
  if (typeof r.confidence_score !== 'number') return { ok: false, error: 'confidence_score required (number)' };
  return { ok: true };
}
